
package putriprojek;


public abstract class Akasir extends javax.swing.JFrame {
   
    public abstract void dataEntry();
    public abstract void kosong();
    public abstract void utama();
}
